import DynamicTabView from "./DynamicTabView";
import DynamicTabViewScrollHeader from "./DynamicTabViewScrollHeader";

export { DynamicTabViewScrollHeader };

export default DynamicTabView;
