# Kleverbook App

This is the updated version of Kleverbook App.

---

## 🚀 How to Run the Project (Step-by-Step)

### 1. Download & Extract
Unzip the project folder first, then open the folder in your terminal or command prompt:

```bash
cd kleverbook-updated-fixed
```

---

### 2. Clean Old Dependencies (Optional but Recommended)

```bash
rm -rf node_modules package-lock.json     # macOS/Linux
# or PowerShell (Windows):
# Remove-Item -Recurse -Force node_modules
# Remove-Item package-lock.json -ErrorAction SilentlyContinue

npm cache clean --force
```

---

### 3. Install Dependencies

```bash
npm install --legacy-peer-deps
```

---

### 4. Fix Security / Dependency Issues

```bash
npm audit fix
```

If issues remain:

```bash
npm audit fix --force
```

---

### 5. Install Local React Native CLI

```bash
npm install --save-dev @react-native-community/cli @react-native-community/cli-platform-android @react-native-community/cli-platform-ios
```

---

### 6. Start Metro Bundler

```bash
npx react-native start
```

---

### 7. Build & Run the Android App

In a separate terminal:

```bash
npx react-native run-android
```

---

## 📌 Update Notes (2025-09-21)
- Removed `react-native-video-player` from dependencies because it conflicted with `react-native-video`.
- The project already contains a custom video player under `change custom code/react-native-video-player/index.js`.
- To install dependencies without issues, always use:

```bash
npm install --legacy-peer-deps
```

---

✅ If you encounter errors, please screenshot and send for assistance.
