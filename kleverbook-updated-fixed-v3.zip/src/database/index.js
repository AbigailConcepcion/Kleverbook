import apis from './apis/index';
import {hitApi} from './services/ApiHelper';
import {hitApi2} from './services/ApiHelper';
export default db = {
  apis,
  hitApi,
  hitApi2,
};
