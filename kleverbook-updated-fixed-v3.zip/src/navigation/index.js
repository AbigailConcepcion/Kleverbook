import HomeStack from './HomeStack';

const stack = {
  HomeStack,
};

export default stack;
