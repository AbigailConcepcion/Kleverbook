//screens
import color from './Color/index';
import window from './Window/index';
import fonts from './Fonts/index';
import DropDown from './DropDown';
// import  Name from "./Strings/index"

export default theme = {
  color,
  window,
  fonts,
  DropDown,
};
