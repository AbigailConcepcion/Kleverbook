let fontNormal = 'Inter-Regular'; //global font
let fontMedium = 'Inter-Medium';
let fontBold = 'Inter-SemiBold';

export default fonts = {
  fontNormal,
  fontMedium,
  fontBold,
};
